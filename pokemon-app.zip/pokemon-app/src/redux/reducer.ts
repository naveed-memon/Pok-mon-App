import { createSlice } from "@reduxjs/toolkit";

export const pokemon = createSlice({
  name: "pokemon",
  initialState: {},
  reducers: {},
});

export const { actions, reducer } = pokemon;
