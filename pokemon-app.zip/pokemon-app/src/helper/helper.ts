export const firstWordCapital = (word:string) => {
    return word[0].toUpperCase() + word.substring(1)
}